/**
 * Assessment Edit Form Page
 *
 * @description Same form as Create but with pre-filled data
 * @route GET /user/assessments/{id}/edit
 */
export { default } from './Create';
